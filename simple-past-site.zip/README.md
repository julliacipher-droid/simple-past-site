# Simple Past - Site Educacional com IA

Este site foi desenvolvido para o trabalho de inglês sobre o tempo verbal **Simple Past**, contendo explicações, tabelas e 12 exercícios auto-corrigíveis.

## 🚀 Como rodar localmente

1. Instale o Node.js (versão 18 ou superior)
2. No terminal, rode:
   ```bash
   npm install
   npm run dev
   ```
3. Abra o navegador em `http://localhost:5173`

## 🌐 Publicar online (Vercel)
1. Crie uma conta gratuita em [https://vercel.com](https://vercel.com)
2. Clique em **Add New → Project**
3. Importe o projeto deste zip
4. Aguarde o deploy e copie o link público (ex: `https://simple-past.vercel.app`)

## 👩‍🏫 Entrega
Envie o link do site por e-mail para `felix.zaniboni@ifba.edu.br` com seu **nome completo** e **turma**.