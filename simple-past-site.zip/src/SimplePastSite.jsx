import React, { useState } from 'react';

export default function SimplePastSite() {
  const [count, setCount] = useState(0);
  return (
    <div className='min-h-screen flex flex-col items-center justify-center bg-slate-50 text-slate-900 p-6'>
      <h1 className='text-3xl font-bold mb-4'>Simple Past - Site Educacional</h1>
      <p className='text-lg mb-6'>Exemplo de site interativo para estudo do tempo verbal Simple Past.</p>
      <button onClick={() => setCount(count + 1)} className='px-4 py-2 bg-indigo-600 text-white rounded-lg'>
        Clique para testar ({count})
      </button>
      <p className='mt-6 text-sm text-slate-500'>Código completo disponível no repositório local.</p>
    </div>
  );
}